#!/bin/bash
# GD Save Keeper: keeps a readable (unencrypted) copy of your GD save data and re-applies it on every launch.
# Steam launch option:  WINEDLLOVERRIDES="xinput1_4=n,b" /path/to/gd_wrapper.sh %command%

SAVE="${GD_SAVE_DIR:-}"
if [ -z "$SAVE" ]; then
  for root in "$HOME/.steam/steam" "$HOME/.steam/debian-installation" "$HOME/.local/share/Steam"; do
    d="$root/steamapps/compatdata/322170/pfx/drive_c/users/steamuser/AppData/Local/GeometryDash"
    if [ -d "$d" ]; then SAVE="$d"; break; fi
  done
fi
: "${SAVE:=$HOME/.steam/steam/steamapps/compatdata/322170/pfx/drive_c/users/steamuser/AppData/Local/GeometryDash}"
STORE="${GD_STORE:-$HOME/GDSaveStore}"
TOOL="$(dirname "$(readlink -f "$0")")/gd_saves.py"
NAMES="CCGameManager CCGameManager2 CCLocalLevels CCLocalLevels2"

mkdir -p "$SAVE" "$STORE/readable" "$STORE/history"
LOG="$STORE/keeper.log"
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

# 1) APPLY: put the readable copy back into the game's save files before launching
for n in $NAMES; do
  xml="$STORE/readable/$n.xml"
  [ -f "$xml" ] || continue
  tmp="$(mktemp)"
  if python3 "$TOOL" encode "$xml" "$tmp" 2>>"$LOG" && [ -s "$tmp" ]; then
    [ -f "$SAVE/$n.dat" ] && cp "$SAVE/$n.dat" "$STORE/history/$n.dat.$(date +%s)"
    cp "$tmp" "$SAVE/$n.dat"
    log "applied $n"
  else
    log "ERROR: could not encode $n.xml, left the game's file alone"
  fi
  rm -f "$tmp"
done

# 2) RUN THE GAME
"$@"
code=$?

# 3) SAVE: after the game closes, store a fresh readable copy
for n in $NAMES; do
  dat="$SAVE/$n.dat"
  [ -f "$dat" ] || continue
  tmp="$(mktemp)"
  if python3 "$TOOL" decode "$dat" "$tmp" 2>>"$LOG" && [ -s "$tmp" ]; then
    mv "$tmp" "$STORE/readable/$n.xml"
    log "saved $n"
  else
    rm -f "$tmp"
    log "ERROR: could not decode $n.dat, kept the old readable copy"
  fi
done

# keep only the 10 newest history backups per file
for n in $NAMES; do
  ls -t "$STORE/history/$n.dat."* 2>/dev/null | tail -n +11 | xargs -r rm -f
done

exit $code

# GD Save Keeper (Windows) - untested
$ErrorActionPreference = "Stop"
$Save     = Join-Path $env:LOCALAPPDATA "GeometryDash"
$Store    = Join-Path $env:USERPROFILE "GDSaveStore"
$Readable = Join-Path $Store "readable"
$History  = Join-Path $Store "history"
$Log      = Join-Path $Store "keeper.log"
$Names    = "CCGameManager","CCGameManager2","CCLocalLevels","CCLocalLevels2"
New-Item -ItemType Directory -Force -Path $Save,$Readable,$History | Out-Null

function Log($m) {
    Add-Content -Path $Log -Value ("{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $m)
}

# GD save format: XOR 11 -> url-safe base64 -> gzip -> XML
function Decode-Save([byte[]]$raw) {
    $x = New-Object byte[] $raw.Length
    for ($i = 0; $i -lt $raw.Length; $i++) { $x[$i] = $raw[$i] -bxor 11 }
    $s = [Text.Encoding]::ASCII.GetString($x).Trim([char[]]@(0, 32, 13, 10))
    $s = $s.Replace("-", "+").Replace("_", "/")
    $s = $s.PadRight($s.Length + ((4 - $s.Length % 4) % 4), "=")
    $bytes = [Convert]::FromBase64String($s)
    $in = New-Object IO.MemoryStream(,$bytes)
    if ($bytes[0] -eq 0x1f -and $bytes[1] -eq 0x8b) {
        $z = New-Object IO.Compression.GZipStream($in, [IO.Compression.CompressionMode]::Decompress)
    } else {
        $in.Position = 2
        $z = New-Object IO.Compression.DeflateStream($in, [IO.Compression.CompressionMode]::Decompress)
    }
    $out = New-Object IO.MemoryStream
    $z.CopyTo($out); $z.Dispose()
    return ,$out.ToArray()
}

function Encode-Save([byte[]]$xml) {
    $ms = New-Object IO.MemoryStream
    $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Compress)
    $gz.Write($xml, 0, $xml.Length); $gz.Close()
    $b64 = [Convert]::ToBase64String($ms.ToArray()).Replace("+", "-").Replace("/", "_")
    $b = [Text.Encoding]::ASCII.GetBytes($b64)
    for ($i = 0; $i -lt $b.Length; $i++) { $b[$i] = $b[$i] -bxor 11 }
    return ,$b
}

# 1) APPLY: readable copy -> game save files
foreach ($n in $Names) {
    $xml = Join-Path $Readable "$n.xml"
    $dat = Join-Path $Save "$n.dat"
    if (-not (Test-Path $xml)) { continue }
    try {
        $enc = Encode-Save ([IO.File]::ReadAllBytes($xml))
        if (Test-Path $dat) {
            $stamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            Copy-Item $dat (Join-Path $History "$n.dat.$stamp")
        }
        [IO.File]::WriteAllBytes($dat, [byte[]]$enc)
        Log "applied $n"
    } catch { Log "ERROR applying ${n}: $_" }
}

# 2) RUN THE GAME (through Steam) and wait for it to close
Start-Process "steam://rungameid/322170"
$proc = $null
for ($i = 0; $i -lt 120 -and -not $proc; $i++) {
    Start-Sleep -Seconds 1
    $proc = Get-Process GeometryDash -ErrorAction SilentlyContinue
}
if ($proc) { $proc | Wait-Process } else { Log "game did not start within 2 minutes" }

# 3) SAVE: game save files -> readable copy
foreach ($n in $Names) {
    $dat = Join-Path $Save "$n.dat"
    $xml = Join-Path $Readable "$n.xml"
    if (-not (Test-Path $dat)) { continue }
    try {
        $dec = Decode-Save ([IO.File]::ReadAllBytes($dat))
        [IO.File]::WriteAllBytes("$xml.tmp", [byte[]]$dec)
        Move-Item -Force "$xml.tmp" $xml
        Log "saved $n"
    } catch { Log "ERROR saving ${n}: $_" }
    Get-ChildItem $History -Filter "$n.dat.*" | Sort-Object LastWriteTime -Descending |
        Select-Object -Skip 10 | Remove-Item -Force
}

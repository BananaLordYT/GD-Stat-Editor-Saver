#!/usr/bin/env python3
"""GD save <-> readable XML converter.
GD save files (CCGameManager.dat etc.) are: XOR 11 -> url-safe base64 -> gzip -> XML.
usage: gd_saves.py decode <file.dat> <out.xml>
       gd_saves.py encode <file.xml> <out.dat>
"""
import sys, gzip, base64, zlib

def decode(raw: bytes) -> bytes:
    x = bytes(b ^ 11 for b in raw)
    x = x.rstrip(b"\x00").strip()
    x = x.replace(b"-", b"+").replace(b"_", b"/")
    x += b"=" * (-len(x) % 4)
    return zlib.decompress(base64.b64decode(x), 15 | 32)  # accepts gzip or zlib

def encode(xml: bytes) -> bytes:
    gz = gzip.compress(xml, mtime=0)
    b64 = base64.b64encode(gz).replace(b"+", b"-").replace(b"/", b"_")
    return bytes(b ^ 11 for b in b64)

if __name__ == "__main__":
    if len(sys.argv) != 4 or sys.argv[1] not in ("decode", "encode"):
        sys.exit(__doc__)
    data = open(sys.argv[2], "rb").read()
    out = decode(data) if sys.argv[1] == "decode" else encode(data)
    open(sys.argv[3], "wb").write(out)

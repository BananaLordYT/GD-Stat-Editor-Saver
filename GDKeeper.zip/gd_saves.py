#!/usr/bin/env python3
"""Geometry Dash save <-> readable XML converter.

Usage:
  gd_saves.py decode INPUT.dat OUTPUT.xml
  gd_saves.py encode INPUT.xml OUTPUT.dat
"""
from __future__ import annotations

import argparse
import base64
import binascii
import os
import tempfile
import zlib
from pathlib import Path


def decode(raw: bytes) -> bytes:
    if not raw:
        raise ValueError("input save is empty")

    encoded = bytes(byte ^ 11 for byte in raw)
    encoded = encoded.strip(b"\x00 \t\r\n")
    encoded = encoded.replace(b"-", b"+").replace(b"_", b"/")
    encoded += b"=" * (-len(encoded) % 4)

    try:
        packed = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("save is not valid base64 data") from exc

    if not packed:
        raise ValueError("decoded save payload is empty")

    try:
        # Accept both gzip and zlib-wrapped Geometry Dash saves.
        result = zlib.decompress(packed, 15 | 32)
    except zlib.error as exc:
        raise ValueError(f"save compression data is invalid: {exc}") from exc

    if not result:
        raise ValueError("decompressed save is empty")
    return result


def encode(xml: bytes) -> bytes:
    if not xml:
        raise ValueError("input XML is empty")

    packed = zlib.compressobj(level=9, wbits=31)
    compressed = packed.compress(xml) + packed.flush()
    encoded = base64.urlsafe_b64encode(compressed)
    return bytes(byte ^ 11 for byte in encoded)


def write_atomically(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("decode", "encode"))
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    try:
        source = args.input.read_bytes()
        result = decode(source) if args.operation == "decode" else encode(source)
        write_atomically(args.output, result)
    except (OSError, ValueError) as exc:
        print(f"gd_saves.py: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

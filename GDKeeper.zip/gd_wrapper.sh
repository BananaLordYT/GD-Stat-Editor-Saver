#!/usr/bin/env bash
# GD Save Keeper - Steam/Proton launch wrapper.
# Steam Launch Options: ~/GDKeeper/gd_wrapper.sh %command%

set -u

NAMES=(CCGameManager CCGameManager2 CCLocalLevels CCLocalLevels2)
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
TOOL="$SCRIPT_DIR/gd_saves.py"
STORE="${GD_STORE:-$HOME/GDSaveStore}"
LOG="$STORE/keeper.log"

log() {
    mkdir -p -- "$STORE"
    printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOG"
}

fail() {
    printf 'GD Save Keeper: %s\n' "$*" >&2
    log "ERROR: $*"
    exit 1
}

[[ -f "$TOOL" ]] || fail "gd_saves.py was not found beside gd_wrapper.sh."
command -v python3 >/dev/null 2>&1 || fail "python3 is required."
(( $# > 0 )) || fail "No game command supplied. Add %command% to Steam Launch Options."

SAVE="${GD_SAVE_DIR:-}"
if [[ -z "$SAVE" ]]; then
    ROOTS=(
        "$HOME/.steam/steam"
        "$HOME/.steam/debian-installation"
        "$HOME/.local/share/Steam"
        "$HOME/.var/app/com.valvesoftware.Steam/.local/share/Steam"
    )
    for root in "${ROOTS[@]}"; do
        candidate="$root/steamapps/compatdata/322170/pfx/drive_c/users/steamuser/AppData/Local/GeometryDash"
        if [[ -d "$candidate" ]]; then
            SAVE="$candidate"
            break
        fi
    done
fi

[[ -n "$SAVE" ]] || fail "Could not find the Geometry Dash save folder. Set GD_SAVE_DIR to its full path."
mkdir -p -- "$SAVE" "$STORE/readable" "$STORE/history" ||
    fail "Could not create the save/store directories."

# Apply edited XML copies before the game starts. A backup must succeed
# before an existing game save is replaced.
for name in "${NAMES[@]}"; do
    xml="$STORE/readable/$name.xml"
    dat="$SAVE/$name.dat"
    [[ -f "$xml" ]] || continue

    tmp="$(mktemp "$SAVE/.${name}.apply.XXXXXX")" ||
        { log "ERROR: cannot create temporary file for $name"; continue; }

    if ! python3 "$TOOL" encode "$xml" "$tmp" >>"$LOG" 2>&1 || [[ ! -s "$tmp" ]]; then
        rm -f -- "$tmp"
        log "ERROR: encoding $name failed; game save unchanged"
        continue
    fi

    if [[ -f "$dat" ]]; then
        backup="$(mktemp "$STORE/history/$name.dat.XXXXXX")" ||
            { rm -f -- "$tmp"; log "ERROR: cannot create backup for $name; game save unchanged"; continue; }
        if ! cp -p -- "$dat" "$backup"; then
            rm -f -- "$tmp" "$backup"
            log "ERROR: backup failed for $name; game save unchanged"
            continue
        fi
    fi

    if mv -f -- "$tmp" "$dat"; then
        log "applied $name"
    else
        rm -f -- "$tmp"
        log "ERROR: could not install $name"
    fi
done

# Run the command Steam passed to this wrapper.
"$@"
GAME_EXIT=$?

# Save readable copies after the game exits. Failed decoding leaves the
# previous readable copy untouched.
for name in "${NAMES[@]}"; do
    dat="$SAVE/$name.dat"
    xml="$STORE/readable/$name.xml"
    [[ -f "$dat" ]] || continue

    tmp="$(mktemp "$STORE/readable/.${name}.XXXXXX")" ||
        { log "ERROR: cannot create output file for $name"; continue; }

    if python3 "$TOOL" decode "$dat" "$tmp" >>"$LOG" 2>&1 && [[ -s "$tmp" ]]; then
        if mv -f -- "$tmp" "$xml"; then
            log "saved $name"
        else
            rm -f -- "$tmp"
            log "ERROR: could not replace readable copy for $name"
        fi
    else
        rm -f -- "$tmp"
        log "ERROR: decoding $name failed; previous readable copy kept"
    fi
done

# Keep the 10 newest backups for each save file.
for name in "${NAMES[@]}"; do
    find "$STORE/history" -maxdepth 1 -type f -name "$name.dat.*" -printf '%T@ %p\n' 2>/dev/null |
        sort -rn | awk 'NR > 10 {$1=""; sub(/^ /,""); print}' |
        while IFS= read -r old; do
            [[ -n "$old" ]] && rm -f -- "$old"
        done
done

exit "$GAME_EXIT"

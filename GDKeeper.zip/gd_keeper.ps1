# GD Save Keeper for Windows PowerShell 5.1+
# Start Geometry Dash using this script/shortcut, not Steam's Play button.

$ErrorActionPreference = 'Stop'

$Save = Join-Path $env:LOCALAPPDATA 'GeometryDash'
$Store = Join-Path $env:USERPROFILE 'GDSaveStore'
$Readable = Join-Path $Store 'readable'
$History = Join-Path $Store 'history'
$Log = Join-Path $Store 'keeper.log'
$Names = @('CCGameManager', 'CCGameManager2', 'CCLocalLevels', 'CCLocalLevels2')

function Write-Log([string]$Message) {
    Add-Content -LiteralPath $Log -Value (
        '{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    )
}

function Write-BytesAtomically([string]$Path, [byte[]]$Bytes) {
    $Temp = "$Path.$([guid]::NewGuid().ToString('N')).tmp"
    try {
        [IO.File]::WriteAllBytes($Temp, $Bytes)
        if ([IO.File]::Exists($Path)) {
            try {
                [IO.File]::Replace($Temp, $Path, $null)
            }
            catch {
                if ([IO.File]::Exists($Temp)) {
                    Move-Item -LiteralPath $Temp -Destination $Path -Force
                }
            }
        }
        else {
            Move-Item -LiteralPath $Temp -Destination $Path
        }
    }
    finally {
        if ([IO.File]::Exists($Temp)) {
            Remove-Item -LiteralPath $Temp -Force -ErrorAction SilentlyContinue
        }
    }
}

function Decode-Save([byte[]]$Raw) {
    if ($null -eq $Raw -or $Raw.Length -eq 0) {
        throw 'Input save is empty.'
    }

    $Xored = New-Object byte[] $Raw.Length
    for ($i = 0; $i -lt $Raw.Length; $i++) {
        $Xored[$i] = $Raw[$i] -bxor 11
    }

    $Text = [Text.Encoding]::ASCII.GetString($Xored).Trim(
        [char[]]@(0, 9, 10, 13, 32)
    )
    if ([string]::IsNullOrWhiteSpace($Text)) {
        throw 'Encoded save is empty.'
    }

    $Text = $Text.Replace('-', '+').Replace('_', '/')
    $Text += '=' * ((4 - ($Text.Length % 4)) % 4)

    try {
        $Packed = [Convert]::FromBase64String($Text)
    }
    catch {
        throw "Invalid base64 save data: $($_.Exception.Message)"
    }
    if ($Packed.Length -lt 3) {
        throw 'Compressed save payload is too short.'
    }

    $InputStream = New-Object IO.MemoryStream(,$Packed)
    $OutputStream = New-Object IO.MemoryStream
    $Decompressor = $null
    try {
        if ($Packed.Length -ge 2 -and $Packed[0] -eq 0x1f -and $Packed[1] -eq 0x8b) {
            $Decompressor = New-Object IO.Compression.GZipStream(
                $InputStream,
                [IO.Compression.CompressionMode]::Decompress
            )
        }
        else {
            # Geometry Dash may use a zlib wrapper. DeflateStream expects
            # the raw DEFLATE stream, so skip the two-byte zlib header.
            $InputStream.Position = 2
            $Decompressor = New-Object IO.Compression.DeflateStream(
                $InputStream,
                [IO.Compression.CompressionMode]::Decompress
            )
        }

        $Decompressor.CopyTo($OutputStream)
        $Result = $OutputStream.ToArray()
        if ($Result.Length -eq 0) {
            throw 'Decompressed save is empty.'
        }
        return ,$Result
    }
    finally {
        if ($null -ne $Decompressor) { $Decompressor.Dispose() }
        $OutputStream.Dispose()
        $InputStream.Dispose()
    }
}

function Encode-Save([byte[]]$Xml) {
    if ($null -eq $Xml -or $Xml.Length -eq 0) {
        throw 'Input XML is empty.'
    }

    $Memory = New-Object IO.MemoryStream
    $Compressor = New-Object IO.Compression.GZipStream(
        $Memory,
        [IO.Compression.CompressionMode]::Compress,
        $true
    )
    try {
        $Compressor.Write($Xml, 0, $Xml.Length)
    }
    finally {
        $Compressor.Dispose()
    }

    $Text = [Convert]::ToBase64String($Memory.ToArray()).
        Replace('+', '-').Replace('/', '_')
    $Memory.Dispose()

    $Bytes = [Text.Encoding]::ASCII.GetBytes($Text)
    for ($i = 0; $i -lt $Bytes.Length; $i++) {
        $Bytes[$i] = $Bytes[$i] -bxor 11
    }
    return ,$Bytes
}

New-Item -ItemType Directory -Force -Path $Save, $Readable, $History | Out-Null

$Running = Get-Process -Name 'GeometryDash' -ErrorAction SilentlyContinue
if ($Running) {
    Write-Log 'ERROR: Geometry Dash is already running; no saves changed.'
    throw 'Close Geometry Dash before starting GD Save Keeper.'
}

# APPLY readable copies. Do not replace an existing save unless its backup succeeds.
foreach ($Name in $Names) {
    $XmlPath = Join-Path $Readable "$Name.xml"
    $DatPath = Join-Path $Save "$Name.dat"
    if (-not (Test-Path -LiteralPath $XmlPath -PathType Leaf)) { continue }

    try {
        $Encoded = Encode-Save ([IO.File]::ReadAllBytes($XmlPath))
        if ($Encoded.Length -eq 0) { throw 'Encoded output is empty.' }

        if (Test-Path -LiteralPath $DatPath -PathType Leaf) {
            $Stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
            $Backup = Join-Path $History (
                "$Name.dat.$Stamp.$([guid]::NewGuid().ToString('N'))"
            )
            Copy-Item -LiteralPath $DatPath -Destination $Backup -ErrorAction Stop
        }

        Write-BytesAtomically $DatPath $Encoded
        Write-Log "applied $Name"
    }
    catch {
        Write-Log "ERROR applying ${Name}: $($_.Exception.Message)"
    }
}

# Launch through Steam and wait for the game process to appear and exit.
try {
    Start-Process -FilePath 'steam://rungameid/322170'
}
catch {
    Write-Log "ERROR launching Steam: $($_.Exception.Message)"
    throw
}

$GameProcess = $null
for ($Attempt = 0; $Attempt -lt 180 -and $null -eq $GameProcess; $Attempt++) {
    Start-Sleep -Seconds 1
    $GameProcess = Get-Process -Name 'GeometryDash' -ErrorAction SilentlyContinue |
        Select-Object -First 1
}

if ($null -eq $GameProcess) {
    Write-Log 'ERROR: Geometry Dash did not start within 3 minutes.'
    throw 'Geometry Dash did not start. Check Steam and try again.'
}

try {
    Wait-Process -Id $GameProcess.Id
}
catch {
    Write-Log "WARNING waiting for Geometry Dash: $($_.Exception.Message)"
}

# SAVE fresh readable copies after the game closes.
foreach ($Name in $Names) {
    $DatPath = Join-Path $Save "$Name.dat"
    $XmlPath = Join-Path $Readable "$Name.xml"
    if (-not (Test-Path -LiteralPath $DatPath -PathType Leaf)) { continue }

    try {
        $Decoded = Decode-Save ([IO.File]::ReadAllBytes($DatPath))
        Write-BytesAtomically $XmlPath $Decoded
        Write-Log "saved $Name"
    }
    catch {
        Write-Log "ERROR saving ${Name}: $($_.Exception.Message)"
    }

    Get-ChildItem -LiteralPath $History -Filter "$Name.dat.*" -File |
        Sort-Object LastWriteTime -Descending |
        Select-Object -Skip 10 |
        Remove-Item -Force -ErrorAction SilentlyContinue
}
